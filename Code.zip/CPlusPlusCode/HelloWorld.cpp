#include <iostream>
 
using namespace std;//使用标准命名空间
 
int main() {
 
    cout << "Hello World!" << endl;
 
    return 0;
 
}